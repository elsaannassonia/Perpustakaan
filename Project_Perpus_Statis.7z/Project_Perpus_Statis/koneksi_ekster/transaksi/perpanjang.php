<?php
$koneksi = mysqli_connect("localhost","root","","db_perpus");

$Id =$_POST['Id'];
$Judul =$_POST['Judul'];
$Tanggal_Kembali =$_POST['Tanggal_Kembali'];

$P_Tanggal_Kembali = explode("-", $Tanggal_Kembali);
$L_7_Hari = mktime(0,0,0,$P_Tanggal_Kembali[1], $P_Tanggal_Kembali[2]+7 ,$P_Tanggal_Kembali[0] );
$hari_L = date("Y-m-d", $L_7_Hari);
$hasil = mysqli_query($koneksi, "UPDATE tab_transaksi SET Tanggal_Kembali='$hari_L' where Id='$Id'");
?>