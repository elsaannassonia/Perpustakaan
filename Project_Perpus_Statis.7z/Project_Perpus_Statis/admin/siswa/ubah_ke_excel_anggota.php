<?php
	include '../koneksi.php';

	$filename = "data_anggota-(".date('d-m-Y').").xls";

	header("content-disposition: attachment; filename =$filename");
	header("content-type: application/vdn.ms.exel");
?>

<h2>Laporan Anggota</h2>

<table border="1">
<tr>
											<th>No</th>
                                            <th>NISN</th>
                                            <th>Nama</th>
                                            <th>Tempat Lahir</th>
                                            <th>Tanggal Lahir</th>
                                            <th>Jenis Kelamin</th>
											<th>Kelas</th>
											
                                        </tr>
	<?php
										
										$no = 1;
										
										$hasil = mysqli_query($koneksi, "select * from tab_anggota");
										
										while ($data= mysqli_fetch_array($hasil)){
											
										$jenisk = ($data['Jenis_Kelamin']=='L')? "Laki-Laki":"Perempuan";
											?>										
										
										<tr>
											
											<td><?php echo $no++ ?></td>
											<td><?php echo $data['NISN']?></td>
											<td><?php echo $data['Nama']?></td>
											<td><?php echo $data['Tempat_Lahir']?></td>
											<td><?php echo $data['Tanggal_Lahir']?></td>
											<td><?php echo $jenisk ?></td>
											<td><?php echo $data['Kelas']?></td>
											
											
											</td>
										</tr>
										<?php }  ?>
</table>
