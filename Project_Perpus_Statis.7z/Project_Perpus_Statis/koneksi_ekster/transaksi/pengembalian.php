<?php
$koneksi = mysqli_connect("localhost","root","","db_perpus");

$Id =$_POST['Id'];
$hasil = mysqli_query($koneksi, "update tab_transaksi set Status='Kembali' where Id='$Id'");
$Judul =$_POST['Judul'];
$hasil = mysqli_query($koneksi, "UPDATE tab_buku SET Jumlah_Buku=(Jumlah_Buku+1) where Judul='$Judul'");
?>