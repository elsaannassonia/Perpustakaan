<?php
header('Content-Type: application/json');
include "db.php";

$stmt = $db->prepare("SELECT NISN, Nama, Tempat_Lahir, Tanggal_Lahir, Jenis_Kelamin, Kelas FROM tab_anggota");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);
?>