<?php
header('Content-Type: application/json');
include "db.php";


$nama = $_POST['Nama'];
$username = $_POST['Username'];
$password = (int) $_POST['Password'];
$level = $_POST['Level'];

$stmt = $db->prepare("INSERT INTO tab_login (Nama, Username, Password, Level) VALUES (?, ?, ?, ?)");
$result = $stmt->execute([$nama, $username, $password, $level]);

echo json_encode([
'success' => $result
]);
?>