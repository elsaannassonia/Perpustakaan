<?php
	include '../koneksi.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perpustakaan Pintar : Ubah Data Buku</title>
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Smart Library</a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  &nbsp; <button type="button" class="btn btn-danger" onclick="myFunction()">Logout</button>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="../assets/img/buku_1.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="../index.php"><i class="fa fa-compass fa-3x"></i> Menu Utama</a>
                    </li>
					<li>
                        <a  class="active-menu" href="data_buku.php"><i class="fa fa-book fa-3x"></i> Data Buku</a>
                    </li>
					<li>
                        <a  href="../siswa/data_siswa.php"><i class="fa fa-users fa-3x"></i> Data Siswa</a>
                    </li>
					<li>
                        <a  href="../transaksi/data_transaksi.php"><i class="fa fa-pencil-square fa-3x"></i> Transaksi</a>
                    </li>
					<li>
                        <a  href="../registrasi/data_login.php"><i class="fa fa-inbox fa-3x"></i> Registrasi</a>
                    </li>
					<li>
                        <a  href="../tentang.php"><i class="fa fa-user fa-3x"></i> Tentang Kami</a>
                    </li>
					
				
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
               		 <h2>Ubah Data Buku</h2>   
                        <h5>Selamat Datang Admin ,Selamat Bekerja. </h5>
						<?php
						
						$Id =@$_GET['Id'];
										
						$hasil1 = mysqli_query($koneksi, "select * from tab_buku where Id='$Id'");
						$data = mysqli_fetch_array($hasil1);
						$tahun1 = $data['Tahun_Terbit'];
						
						?>
						<div class="panel panel-default">
                        <div class="panel-heading">
							Ubah Data Buku
							</div>
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST">
                                        <div class="form-group">
                                            <label>Judul</label>
                                            <input class="form-control" name="Judul" value="<?php echo $data['Judul'];?>" required/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Pengarang</label>
                                            <input class="form-control" name="Pengarang" value="<?php echo $data['Pengarang'];?>" required/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Penerbit</label>
                                            <input class="form-control" name="Penerbit" value="<?php echo $data['Penerbit'];?>" required/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Tahun Terbit</label>
                                            <select class="form-control" name="Tahun_Terbit">
                                                <?php
													
													$tahun = date("Y");
													
													for($i=$tahun-50; $i <= $tahun; $i++) {
														
														
															if($i == $tahun1) {
															
															echo'<option value = "'.$i.'"selected>'.$i.'</option>';		
															}
															else{
															echo'<option value = "'.$i.'">'.$i.'</option>';
															}
														
													
													}					
												
												?>
                                            </select>
                                        </div>
										<div class="form-group">
                                            <label>ISBN</label>
                                            <input class="form-control" name="Isbn" value="<?php echo $data['Isbn'];?>" required/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Jumlah Buku</label>
                                            <input class="form-control" type="number" name="Jumlah_Buku" value="<?php echo $data['Jumlah_Buku'];?>" required/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Lokasi</label>
                                            <select class="form-control" name="Lokasi">
                                                <option value="001" <?php if ($data['Lokasi'] == '001'){echo "selected";}?> >001</option>
                                                <option value="002" <?php if ($data['Lokasi'] == '002'){echo "selected";}?> >002</option>
                                                <option value="003" <?php if ($data['Lokasi'] == '003'){echo "selected";}?> >003</option>
                                                <option value="004" <?php if ($data['Lokasi'] == '004'){echo "selected";}?> >004</option>
												<option value="005" <?php if ($data['Lokasi'] == '005'){echo "selected";}?> >005</option>
												<option value="006" <?php if ($data['Lokasi'] == '006'){echo "selected";}?> >006</option>
												<option value="007" <?php if ($data['Lokasi'] == '007'){echo "selected";}?> >007</option>
												<option value="008" <?php if ($data['Lokasi'] == '008'){echo "selected";}?> >008</option>
												<option value="009" <?php if ($data['Lokasi'] == '009'){echo "selected";}?> >009</option>
												<option value="010" <?php if ($data['Lokasi'] == '010'){echo "selected";}?> >010</option>
                                            </select>
                                        </div>
										<div class="form-group">
                                            <label>Tanggal Registrasi</label>
                                            <input class="form-control" name="Tanggal_Registrasi" type=date value="<?php echo $data['Tanggal_Registrasi'];?>" />
                                            
                                        </div>
										
										<div>
											
											<input type="submit" name="Simpan" value="Simpan" class="btn btn-primary">
										
										
										
										
						</div>
                </div>
				</form>
			</div>
		</div>
	</div>
						<?php
						
						
						$Judul = @$_POST['Judul'];
						$Pengarang = @$_POST['Pengarang'];
						$Penerbit = @$_POST['Penerbit'];
						$Tahun_Terbit = @$_POST['Tahun_Terbit'];
						$Isbn = @$_POST['Isbn'];
						$Jumlah_Buku = @$_POST['Jumlah_Buku'];
						$Lokasi = @$_POST['Lokasi'];
						$Tanggal_Registrasi = @$_POST['Tanggal_Registrasi'];
						
						$Simpan = @$_POST['Simpan'];
						
						
						if ($Simpan) {
  
							$hasil = mysqli_query($koneksi, "UPDATE tab_buku SET Judul='$Judul', Pengarang='$Pengarang', Penerbit='$Penerbit', Tahun_Terbit='$Tahun_Terbit', ISBN='$Isbn', Jumlah_Buku='$Jumlah_Buku', Lokasi='$Lokasi', Tanggal_Registrasi='$Tanggal_Registrasi' where Id='$Id'");

  						if ($hasil) {
   							?>

  						<script type="text/javascript">
    
    						alert("Data Berhasil Diubah");
							window.location.href="data_buku.php";
							
						</script>

   						<?php
  							}
 							}

							?>
                    </div>
                </div>
                 <hr />
               
    </div>
            </div>
        </div>
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.metisMenu.js"></script>
    <script src="../assets/js/custom.js"></script>
    <script>
        function myFunction() {
        if (confirm('Yakin Akan Logout??')) { 
                window.location='../logout.php'; 
                }else{
                window.location='index.php';
                }
}
        
    </script>
    
   
</body>
</html>
