<?php
	include '../koneksi.php';

	$filename = "data_buku-(".date('d-m-Y').").xls";

	header("content-disposition: attachment; filename =$filename");
	header("content-type: application/vdn.ms.exel");
?>

<h2>Laporan Buku</h2>

<table border="1">
<tr>
                                            <th>Id</th>
                                            <th>Judul</th>
                                            <th>Pengarang</th>
                                            <th>Penerbit</th>
                                            <th>Tahun Terbit</th>
											<th>Isbn</th>
											<th>Jumlah Buku</th>
											<th>Lokasi</th>
											<th>Tanggal Registrasi</th>
											
                                        </tr>
	<?php
										$no = 1;
										$hasil = mysqli_query($koneksi, "select * from tab_buku");
										
										
										while ($data= mysqli_fetch_array($hasil)){	
											?>
	
										<tr>
											<td><?php echo $no++ ?></td>
											<td><?php echo $data['Judul']?></td>
											<td><?php echo $data['Pengarang']?></td>
											<td><?php echo $data['Penerbit']?></td>
											<td><?php echo $data['Tahun_Terbit']?></td>
											<td><?php echo $data['Isbn']?></td>
											<td><?php echo $data['Jumlah_Buku']?></td>
											<td><?php echo $data['Lokasi']?></td>
											<td><?php echo $data['Tanggal_Registrasi']?></td>
											
										</tr>
										<?php }  ?>
</table>
