<?php
include '../koneksi.php';

$Id =$_GET['Id'];
$hasil = mysqli_query($koneksi, "update tab_transaksi set Status='Kembali' where Id='$Id'");
$Judul =$_GET['Judul'];
$hasil = mysqli_query($koneksi, "UPDATE tab_buku SET Jumlah_Buku=(Jumlah_Buku+1) where Judul='$Judul'");

?>
<script type="text/javascript">
			alert("Buku telah dikembalikan!");
			window.location.href="data_transaksi.php";
			</script>


