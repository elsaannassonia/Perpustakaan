<?php
	include '../koneksi.php';
	include '../assets/fungsi_barcode.php';

	$filename = "barcode-(".@$_GET=['Judul'].").xls";

	header("content-disposition: attachment; filename =$filename");
	header("content-type: application/vdn.ms.exel");

	$Id =@$_GET['Id'];
	$Judul =@$_GET['Judul'];
										
	$hasil1 = mysqli_query($koneksi, "select * from tab_buku where Id='$Id'");
	$data = mysqli_fetch_array($hasil1);
	
	
	
	
?>