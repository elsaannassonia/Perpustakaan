<?php
declare(strict_types=1);

use PHPUnit\Framework\TestCase;

class aksi_loginTest extends TestCase
{

}
?>