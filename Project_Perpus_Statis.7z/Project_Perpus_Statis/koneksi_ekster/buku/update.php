<?php
header('Content-Type: application/json');
include "db.php";

$id = $_POST['Id'];
$judul = $_POST['Judul'];
$pengarang = $_POST['Pengarang'];
$penerbit = $_POST['Penerbit'];
$tahuntrbt = (int) $_POST['Tahun_Terbit'];
$isbn = (int) $_POST['Isbn'];
$jmlhbku = (int) $_POST['Jumlah_Buku'];
$lokasi = (int) $_POST['Lokasi'];

$stmt = $db->prepare("UPDATE tab_buku SET Judul = ?, Pengarang = ?, Penerbit = ?, Tahun_Terbit = ?, Isbn = ?, Jumlah_Buku = ?, Lokasi = ? WHERE Id = ?");
$result = $stmt->execute([$judul, $pengarang, $penerbit, $tahuntrbt, $isbn, $jmlhbku, $lokasi, $id]);

echo json_encode([
'success' => $result
]);
?>