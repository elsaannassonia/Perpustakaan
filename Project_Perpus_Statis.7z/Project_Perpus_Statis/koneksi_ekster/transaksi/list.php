<?php
header('Content-Type: application/json');
include "db.php";

$stmt = $db->prepare("SELECT Id, Judul, Nisn, Nama, Tanggal_Minjam, Tanggal_Kembali, Status FROM tab_transaksi WHERE Status = 'Pinjam' ");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);
?>