<?php
include "../koneksi.php";

	$Id =$_GET['Id'];
	$Judul =$_GET['Judul'];
	$lambat =$_GET['lambat'];
	$Tanggal_Kembali =$_GET['Tanggal_Kembali'];

if($lambat > 7){
	?>
	<script type="text/javascript">
			alert("Pinjaman buku tidak dapat diperpanjang karena lebih dari 7 hari!,Kembalikan Dahulu!");
			window.location.href="data_transaksi.php";
	</script>
	<?php
}else{
	$P_Tanggal_Kembali = explode("-", $Tanggal_Kembali);
	$L_7_Hari = mktime(0,0,0,$P_Tanggal_Kembali[1], $P_Tanggal_Kembali[2]+7 ,$P_Tanggal_Kembali[0] );
	$hari_L = date("Y-m-d", $L_7_Hari);
	
	$hasil = mysqli_query($koneksi, "UPDATE tab_transaksi SET Tanggal_Kembali='$hari_L' where Id='$Id'");
	if($hasil){
		?>
		<script type="text/javascript">
			alert("Perpanjangan Berhasil!");
			window.location.href="data_transaksi.php";
		</script>

		<?php
	}else{
		?>

		<script type="text/javascript">
			alert("Perpanjangan Gagal!");
			window.location.href="data_transaksi.php";
		</script>
		
		<?php
		
	}
}

?>