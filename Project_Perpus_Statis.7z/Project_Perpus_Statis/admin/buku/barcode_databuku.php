<body onLoad="javascrip:window:print()">

<?php
include('../assets/fungsi_barcode.php');
include "../koneksi.php"; 

$kolom = 5;  
$copy = $_GET['Jumlah_Buku'];
$counter = 1;

$Isbn = $_GET['Isbn'];
$Id = $_GET['Id'];

$baca_barcode = mysqli_query($koneksi, "SELECT * FROM tab_buku WHERE Isbn='$Isbn' AND Id='$Id'");
$data_barcode = mysqli_fetch_array($baca_barcode);

echo"
<table cellpadding='10'>";
for ($ucopy=1; $ucopy<=$copy; $ucopy++) {
if (($counter-1) % $kolom == '0') { echo "
<tr>"; }
echo"
<td class='merk'>".substr($data_barcode['Judul'],0,20)."";
echo bar128(stripslashes($_GET['Isbn']));
echo "</td>
";
if ($counter % $kolom == '0') { echo "</tr>
"; }
$counter++;
}
echo "</table>
";
?>