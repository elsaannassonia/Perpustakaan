<?php
	include '../koneksi.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perpustakaan Pintar : Registrasi</title>

    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Smart Library</a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  &nbsp; <button type="button" class="btn btn-danger" onclick="myFunction()">Logout</button>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="../assets/img/buku_1.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="../index.php"><i class="fa fa-compass fa-3x"></i> Menu Utama</a>
                    </li>
					<li>
                        <a  href="../buku/data_buku.php"><i class="fa fa-book fa-3x"></i> Data Buku</a>
                    </li>
					<li>
                        <a class="active-menu" href="data_siswa.php"><i class="fa fa-users fa-3x"></i> Data Siswa</a>
                    </li>
					<li>
                        <a  href="../transaksi/data_transaksi.php"><i class="fa fa-pencil-square fa-3x"></i> Transaksi</a>
                    </li>
					<li>
                        <a  href="../registrasi/data_login.php"><i class="fa fa-inbox fa-3x"></i> Registrasi</a>
                    </li>
					<li>
                        <a  href="../tentang.php"><i class="fa fa-user fa-3x"></i> Tentang Kami</a>
                    </li>
					
				
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
               		 <h2>Data Siswa</h2>   
                        <h5>Selamat Datang Admin ,Selamat Bekerja. </h5>
					<?php
						
						$NISN1 =@$_GET['NISN'];
										
						$hasil1 = mysqli_query($koneksi, "select * from tab_anggota where NISN='$NISN1'");
						$data = mysqli_fetch_array($hasil1);
						
						$JK = $data['Jenis_Kelamin'];
						
						?>
					<div class="panel panel-default">
                        <div class="panel-heading">
							Tambah Data Buku
							</div>
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST">
                                        <div class="form-group">
                                            <label>NISN</label>
                                            <input class="form-control" name="NISN" value="<?php echo $data['NISN'];?>" readonly />
                                            
                                        </div>
										<div class="form-group">
                                            <label>Nama</label>
                                            <input class="form-control" name="Nama" value="<?php echo $data['Nama'];?>" />
                                            
                                        </div>
										<div class="form-group">
                                            <label>Tempat Lahir</label>
                                            <input class="form-control" name="Tempat_Lahir" value="<?php echo $data['Tempat_Lahir'];?>" />
                                            
                                        </div>
										<div class="form-group">
                                            <label>Tanggal Lahir</label>
                                            <input class="form-control" name="Tanggal_Lahir" type=date value="<?php echo $data['Tanggal_Lahir'];?>" />
                                            
                                        </div>
										<div class="form-group">
                                            <label>Jenis Kelamin</label>
                                            <label class="checkbox-inline">
                                                <input type="checkbox" name="Jenis_Kelamin" value="L" <?php echo($JK=='L')?"checked":""; ?> /> Laki-Laki
                                            </label>
                                            <label class="checkbox-inline">
                                                <input type="checkbox" name="Jenis_Kelamin" value="P" <?php echo($JK=='P')?"checked":""; ?> /> Perempuan
                                            </label>
                                        </div>
										<div class="form-group">
                                            <label>Kelas</label>
                                            <input class="form-control" name="Kelas" value="<?php echo $data['Kelas'];?>" />
										</div>
										<div>
											
											<input type="submit" name="Simpan" value="Simpan" class="btn btn-primary">
										
										
										
										
						</div>
                </div>
				</form>
			</div>
		</div>
	</div>
						<?php
						
						
						$NISN = @$_POST['NISN'];
						$Nama = @$_POST['Nama'];
						$Tempat_Lahir = @$_POST['Tempat_Lahir'];
						$Tanggal_Lahir = @$_POST['Tanggal_Lahir'];
						$Jenis_Kelamin = @$_POST['Jenis_Kelamin'];
						$Kelas = @$_POST['Kelas'];
						
						$Simpan = @$_POST['Simpan'];
						
						
						if ($Simpan) {
  
							$hasil = mysqli_query($koneksi, "UPDATE tab_anggota SET NISN='$NISN', Nama='$Nama', Tempat_Lahir='$Tempat_Lahir', Tanggal_Lahir='$Tanggal_Lahir', Jenis_Kelamin='$Jenis_Kelamin', Kelas='$Kelas' where NISN='$NISN1'");

  						if ($hasil) {
   							?>

  						<script type="text/javascript">
    
    						alert("Data Berhasil Diubah");
							window.location.href="data_siswa.php";
							
						</script>

   						<?php
  							}
 							}

							?>
						
                 <hr />
               
    </div>
            </div>
        </div>
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.metisMenu.js"></script>
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <script src="../assets/js/custom.js"></script>
    <script>
        function myFunction() {
        if (confirm('Yakin Akan Logout??')) { 
                window.location='../logout.php'; 
                }else{
                window.location='index.php';
                }
}
        
    </script>
   
</body>
</html>
