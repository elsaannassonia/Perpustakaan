<?php

function terlambat($Tanggal_Deathline, $Tanggal_Kembali){

$Tanggal_Deathline_Sampai = explode("-", $Tanggal_Deathline);
$Tanggal_Deathline_Sampai = $Tanggal_Deathline_Sampai[2]."-".$Tanggal_Deathline_Sampai[1]."-".$Tanggal_Deathline_Sampai[0];

$Tanggal_Kembali_Sampai = explode("-", $Tanggal_Kembali);
$Tanggal_Kembali_Sampai = $Tanggal_Kembali_Sampai[2]."-".$Tanggal_Kembali_Sampai[1]."-".$Tanggal_Kembali_Sampai[0];

$selisih = strtotime($Tanggal_Kembali)-strtotime($Tanggal_Deathline_Sampai);

$selisih = $selisih/86400;

if ($selisih>=1) {
	$hasil_tanggal = floor($selisih);
}else{
	$hasil_tanggal = 0;
}
return $hasil_tanggal;
}
?>