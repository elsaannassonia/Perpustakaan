<?php
header('Content-Type: application/json');
include "db.php";

$Id = (int) $_POST['Id'];

$stmt = $db->prepare("SELECT Judul, Pengarang, Penerbit, Tahun_Terbit, Isbn, Jumlah_Buku, Lokasi, Tanggal_Registrasi FROM tab_buku WHERE Id = ?");
$stmt->execute([$Id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
'result' => $result
]);
?>