<?php
header('Content-Type: application/json');
include "db.php";

$Id = (int) $_POST['Id'];

$stmt = $db->prepare("SELECT Judul, Nisn, Nama, Tanggal_Minjam, Tanggal_Kembali, Status FROM tab_transaksi WHERE Id = ?");
$stmt->execute([$Id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
'result' => $result
]);
?>