<?php
header('Content-Type: application/json');
include "db.php";


$nisn = $_POST['NISN'];
$nama = $_POST['Nama'];
$tmptlahir = $_POST['Tempat_Lahir'];
$tgllahir = $_POST['Tanggal_Lahir'];
$jnskelamin = $_POST['Jenis_Kelamin'];
$kelas = (int) $_POST['Kelas'];

$stmt = $db->prepare("INSERT INTO tab_anggota (NISN, Nama, Tempat_Lahir, Tanggal_Lahir, Jenis_Kelamin, Kelas) VALUES (?, ?, ?, ?, ?, ?)");
$result = $stmt->execute([$nisn, $nama, $tmptlahir, $tgllahir, $jnskelamin, $kelas]);

echo json_encode([
'success' => $result
]);
?>