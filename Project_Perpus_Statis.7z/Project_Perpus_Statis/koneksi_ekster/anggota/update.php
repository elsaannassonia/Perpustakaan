<?php
header('Content-Type: application/json');
include "db.php";

$nisn = (int) $_POST['NISN'];
$nama = $_POST['Nama'];
$tmptlahir = $_POST['Tempat_Lahir'];
$tgllahir = $_POST['Tanggal_Lahir'];
$jnskelamin = $_POST['Jenis_Kelamin'];
$kelas = (int) $_POST['Kelas'];

$stmt = $db->prepare("UPDATE tab_anggota SET Nama = ?, Tempat_Lahir = ?, Tanggal_Lahir = ?, Jenis_Kelamin = ?, Kelas = ? WHERE NISN = ?");
$result = $stmt->execute([$nama, $tmptlahir, $tgllahir, $jnskelamin, $kelas, $nisn]);

echo json_encode([
'success' => $result
]);
?>