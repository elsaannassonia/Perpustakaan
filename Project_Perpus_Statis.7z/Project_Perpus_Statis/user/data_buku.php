<?php
	include '../koneksi.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perpustakaan Pintar : Mencari Buku</title>

    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Smart Library</a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  &nbsp; <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/buku_1.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="index.php"><i class="fa fa-compass fa-3x"></i> Menu Utama</a>
                    </li>
					<li>
                        <a class="active-menu" href="data_buku.php"><i class="fa fa-search fa-3x"></i> Mencari Buku</a>
                    </li>
					<li>
                        <a  href="tentang.php"><i class="fa fa-user fa-3x"></i> Tentang Kami</a>
                    </li>
					
				
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
               		 <h2>Pencarian Buku</h2>   
                        <h5>Selamat Datang Di Perpustakaan. </h5>
						
						
						
						
						
						<div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Data Buku
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Judul</th>
                                            <th>Pengarang</th>
                                            <th>Penerbit</th>
                                            <th>Tahun Terbit</th>
											<th>Isbn</th>
											<th>Jumlah Buku</th>
											<th>Lokasi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
										<?php
										$no = 1;
										$hasil = mysqli_query($koneksi, "select * from tab_buku");
										
										
										while ($data= mysqli_fetch_array($hasil)){	
											?>										
										
										<tr>
											<td><?php echo $no++ ?></td>
											<td><?php echo $data['Judul']?></td>
											<td><?php echo $data['Pengarang']?></td>
											<td><?php echo $data['Penerbit']?></td>
											<td><?php echo $data['Tahun_Terbit']?></td>
											<td><?php echo $data['Isbn']?></td>
											<td><?php echo $data['Jumlah_Buku']?></td>
											<td><?php echo $data['Lokasi']?></td>
										</tr>
										<?php }  ?>
										
									


                    </div>
                </div>
                 <hr />
               
    </div>
            </div>
        </div>
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.metisMenu.js"></script>
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <script src="../assets/js/custom.js"></script>
    
    
   
</body>
</html>
