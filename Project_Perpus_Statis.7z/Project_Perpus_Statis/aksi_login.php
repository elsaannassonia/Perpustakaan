﻿<?php
session_start();

include "koneksi.php";

$username = $_POST["username"];
$p = ($_POST["password"]);

$sql = "select * from Tab_Login where Username='".$username."' and Password='".$p."' limit 1";
$hasil = mysqli_query ($koneksi,$sql);
$jumlah = mysqli_num_rows($hasil);

global $session, $form;
if (!isset($_SESSION['tries'])) $_SESSION['tries'] = 0;
if ($_SESSION['tries'] < 2) {

	if ($jumlah>0) {
		print($jumlah);
		$row = mysqli_fetch_assoc($hasil);
		$_SESSION['tries'] = 0;
		$_SESSION["id_user"]=$row["id_user"];
		$_SESSION["username"]=$row["username"];
		$_SESSION["nama"]=$row["nama"];
		$_SESSION["email"]=$row["email"];
        $_SESSION["level"]=$row["level"];


        if ($_SESSION["level"]=$row["Level"]==admin)
        {
            header("Location:admin/index.php");
        } else if ($_SESSION["level"]=$row["Level"]==user)
        {
            header("Location:user/index.php");
        }

		
	}else {
		$_SESSION['tries'] += 1;
		$_SESSION['value_array'] = $_POST;
		echo "Username atau password salah <br><a href='index.php'>Kembali</a>";
	}
} else {
	echo "Username atau password salah 3 kali!!! Browser Anda Di Block<br>";
}

	
?>