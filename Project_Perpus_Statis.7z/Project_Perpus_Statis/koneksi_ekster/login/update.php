<?php
header('Content-Type: application/json');
include "db.php";

$id = $_POST['Id'];
$nama = $_POST['Nama'];
$username = $_POST['Username'];
$password = (int) $_POST['Password'];

$stmt = $db->prepare("UPDATE tab_login SET Nama = ?, Username = ?, Password = ? WHERE Id = ?");
$result =  $stmt->execute([$nama, $username, $password, $id]);

echo json_encode([
'success' => $result
]);
?>