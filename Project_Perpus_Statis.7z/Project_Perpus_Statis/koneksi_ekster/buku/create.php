<?php
header('Content-Type: application/json');
include "db.php";


$judul = $_POST['Judul'];
$pengarang = $_POST['Pengarang'];
$penerbit = $_POST['Penerbit'];
$tahuntrbt = (int) $_POST['Tahun_Terbit'];
$isbn = (int) $_POST['Isbn'];
$jmlhbku = (int) $_POST['Jumlah_Buku'];
$lokasi = (int) $_POST['Lokasi'];
$tglregis = $_POST['Tanggal_Registrasi'];

$stmt = $db->prepare("INSERT INTO tab_buku (Judul, Pengarang, Penerbit, Tahun_Terbit, Isbn, Jumlah_Buku, Lokasi, Tanggal_Registrasi) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$result = $stmt->execute([$judul, $pengarang, $penerbit, $tahuntrbt, $isbn, $jmlhbku, $lokasi, $tglregis,]);

echo json_encode([
'success' => $result
]);
?>