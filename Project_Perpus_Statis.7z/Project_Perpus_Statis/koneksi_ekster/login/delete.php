<?php
header('Content-Type: application/json');
include "db.php";

$Id = (int) $_POST['Id'];
$stmt = $db->prepare("DELETE FROM tab_login WHERE Id = ?");
$result = $stmt->execute([$Id]);

echo json_encode([
'Id' => $Id,
'success' => $result
]);
?>