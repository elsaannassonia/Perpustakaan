<?php
header('Content-Type: application/json');
include "db.php";

$koneksi = mysqli_connect("localhost","root","","db_perpus");

$judul = $_POST['Judul'];
$nisn = $_POST['Nisn'];
$nama = $_POST['Nama'];
$tglmnjm = $_POST['Tanggal_Minjam'];
$tglkmbl = $_POST['Tanggal_Kembali'];
$status = $_POST['Status'];

$stmt = $db->prepare("INSERT INTO tab_transaksi (Judul, Nisn, Nama, Tanggal_Minjam, Tanggal_Kembali, Status) VALUES (?, ?, ?, ?, ?, ?)");
$result = $stmt->execute([$judul, $nisn ,$nama, $tglmnjm, $tglkmbl, $status]);
$hasil2 = mysqli_query($koneksi, "UPDATE tab_buku SET Jumlah_Buku=(Jumlah_Buku-1) where Judul='$judul'");
echo json_encode([
'success' => $result
]);
?>