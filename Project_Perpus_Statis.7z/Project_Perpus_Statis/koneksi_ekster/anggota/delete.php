<?php
header('Content-Type: application/json');
include "db.php";

$NISN = (int) $_POST['NISN'];
$stmt = $db->prepare("DELETE FROM tab_anggota WHERE NISN = ?");
$result = $stmt->execute([$NISN]);

echo json_encode([
'NISN' => $NISN,
'success' => $result
]);
?>