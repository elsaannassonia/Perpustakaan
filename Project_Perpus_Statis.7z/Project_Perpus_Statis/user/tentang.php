<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perpustakaan Pintar : Tentang</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Smart Library</a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  &nbsp; <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/buku_1.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="index.php"><i class="fa fa-compass fa-3x"></i> Menu Utama</a>
                    </li>
					<li>
                        <a  href="data_buku.php"><i class="fa fa-search fa-3x"></i> Mencari Buku</a>
                    </li>
					<li>
                        <a class="active-menu" href="tentang.php"><i class="fa fa-user fa-3x"></i> Tentang Kami</a>
                    </li>
				
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
               		 <h2>Tentang</h2>   
                        
						<h5> Aplikasi ini adalah aplikasi perpustakaan yang memanajemen siswa, inventori atau jumlah buku yang ada pada pepustakaan SMP Muhamadiyah 06 DAU Yang dikembangkan oleh mahasiswa Universitas Muhamadiyah Malang.</h5>
                    </div>
                </div>
				<h4>Aplikasi ini dikembangkan oleh :</h4>
                 <hr />
            <div class="row">
                <div class="col-md-4 col-sm-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Analisa
                        </div>
                        <div class="panel-body">
                            <p><?php echo nl2br ("Nama : Budiman Hamsyurah \n E-Mail : budimanh34@gmail.com \n No-HP : 085387131333 \n Motto : so fun and santuy");?>
							</p>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Desainer
                        </div>
                        <div class="panel-body">
                            <p><?php echo nl2br ("Nama : Muhammad Zaki Kurniawan \n E-Mail : kurniawan.zaki279@gmail.com \n No-HP : 081255690927 \n Motto : Selalu optimis");?></p>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
				
                <div class="col-sm-4 col-md-4">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            Implementator
                        </div>
                        <div class="panel-body">
                            <p><?php echo nl2br ("Nama : Rama Haryamadha \n E-Mail : haryamadha37@gmail.com \n No-HP : 081333402835 \n Motto : Always Coding And Keep Learn!");?></p>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
            </div>
                   
            <div class="row">
                <div class="col-sm-4 col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Penanggung Jawab
                        </div>
                        <div class="panel-body">
                            <p><?php echo nl2br ("Nama : Roy Inzaqhi Saputra \n E-Mail : royinzaqhi@gmail.com \n No-HP : 082156985921 \n Motto : Lebih baik ribuan kali masuk akal tanpa pendidikan dari pada pendidikan tanpa masuk akal");?></p>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
				<div class="col-sm-4 col-md-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            Dosen Pembimbing
                        </div>
                        <div class="panel-body">
                            <p><?php echo nl2br ("Nama : Didih Rizki, S.Kom, M.Kom  \n E-Mail : @gmail.com \n No-HP :  \n Motto : ");?></p>
                        </div>
                        <div class="panel-footer">
                        </div>
                    </div>
                </div>
               
    </div>
            </div>
        </div>
    <script src="assets/js/jquery-1.10.2.js"></script>

    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.metisMenu.js"></script>
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
