<?php
header('Content-Type: application/json');
include "db.php";

$NISN = (int) $_POST['NISN'];

$stmt = $db->prepare("SELECT Nama, Tempat_Lahir, Jenis_Kelamin, Kelas FROM tab_anggota WHERE NISN = ?");
$stmt->execute([$NISN]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
'result' => $result
]);
?>