<?php
header('Content-Type: application/json');
include "db.php";

$stmt = $db->prepare("SELECT Id, Nama, Username, Password, Level FROM tab_login");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);
?>