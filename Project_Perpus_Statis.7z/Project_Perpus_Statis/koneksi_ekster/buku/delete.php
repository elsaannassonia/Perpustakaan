<?php
header('Content-Type: application/json');
include "db.php";

$id = (int) $_POST['Id'];
$stmt = $db->prepare("DELETE FROM tab_buku WHERE Id = ?");
$result = $stmt->execute([$id]);

echo json_encode([
'Id' => $id,
'success' => $result
]);
?>