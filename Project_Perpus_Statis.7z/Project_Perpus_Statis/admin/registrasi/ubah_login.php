<?php
	include '../koneksi.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perpustakaan Pintar : Registrasi</title>
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/custom.css" rel="stylesheet" />
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="../assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Smart Library</a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Akses terakhir : 04 Des 2019 &nbsp; <button type="button" class="btn btn-danger" onclick="myFunction()">Logout</button>
        </nav>   
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="../assets/img/buku_1.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a  href="../index.php"><i class="fa fa-compass fa-3x"></i> Menu Utama</a>
                    </li>
					<li>
                        <a  href="../buku/data_buku.php"><i class="fa fa-book fa-3x"></i> Data Buku</a>
                    </li>
					<li>
                        <a  href="../siswa/data_siswa.php"><i class="fa fa-users fa-3x"></i> Data Siswa</a>
                    </li>
					<li>
                        <a  href="../transaksi/data_transaksi.php"><i class="fa fa-pencil-square fa-3x"></i> Transaksi</a>
                    </li>
					<li>
                        <a  class="active-menu" href="data_login.php"><i class="fa fa-inbox fa-3x"></i> Registrasi</a>
                    </li>
					<li>
                        <a  href="../tentang.php"><i class="fa fa-user fa-3x"></i> Tentang Kami</a>
                    </li>
					
				
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
               		 <h2>Registrasi User</h2>   
                        <h5>Selamat Datang Admin ,Selamat Bekerja. </h5>
						<?php
						
						$Id1 =@$_GET['Id'];
										
						$hasil1 = mysqli_query($koneksi, "select * from tab_login where Id='$Id1'");
						$data = mysqli_fetch_array($hasil1);
						
						?>
						<div class="panel panel-default">
                        <div class="panel-heading">
							Registrasi User
							</div>
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST">
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input class="form-control" name="Nama" value="<?php echo $data['Nama'];?>"/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Username</label>
                                            <input class="form-control" name="Username" value="<?php echo $data['Username'];?>"/>
                                            
                                        </div>
										<div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" name="Password" value="<?php echo $data['Password'];?>"/>
                                            
                                        </div>
										<div>
											
											<input type="submit" name="Simpan" value="Simpan" class="btn btn-primary">
										
										
										
										
						</div>
                </div>
				</form>
			</div>
		</div>
	</div>
						<?php
						
						
						$Nama = @$_POST['Nama'];
						$Username = @$_POST['Username'];
						$Password = @$_POST['Password'];
						$Level = @_POST['Level'];
						
						$Simpan = @$_POST['Simpan'];
						
						
						if ($Simpan) {
  
							$hasil = mysqli_query($koneksi, "UPDATE tab_login SET Nama='$Nama', Username='$Username', Password='$Password', Level= 'user' where Id='$Id1'");

  						if ($hasil) {
   							?>

  						<script type="text/javascript">
    
    						alert("Data Berhasil Disimpan");
							window.location.href="data_login.php";
							
						</script>

   						<?php
  							}
 							}

							?>
										
										
										
                    </div>
                </div>
                 <hr />
               
    </div>
            </div>
        </div>
    <script src="../assets/js/jquery-1.10.2.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.metisMenu.js"></script>
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <script src="../assets/js/custom.js"></script>
    <script>
        function myFunction() {
        if (confirm('Yakin Akan Logout??')) { 
                window.location='../logout.php'; 
                }else{
                window.location='index.php';
                }
}
        
    </script>
   
</body>
</html>
